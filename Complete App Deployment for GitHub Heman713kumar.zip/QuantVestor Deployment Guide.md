# QuantVestor Deployment Guide

This guide provides step-by-step instructions for deploying the QuantVestor application to production.

## Prerequisites

- GitHub account
- Railway account (for backend deployment)
- Netlify account (for frontend deployment)

## Backend Deployment (Railway)

### Option 1: Using Railway Dashboard (Recommended)

1. **Connect GitHub Repository**
   - Go to [Railway Dashboard](https://railway.app/dashboard)
   - Click "New Project"
   - Select "Deploy from GitHub repo"
   - Connect your GitHub account and select the QuantVestor repository

2. **Configure Deployment**
   - Railway will automatically detect the Python application
   - Set the **Start Command** to: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
   - No additional environment variables are required for basic functionality

3. **Deploy**
   - Click "Deploy" and wait for the build to complete
   - Railway will provide a public URL (e.g., `https://quantvestor-production.up.railway.app`)

### Option 2: Using Railway CLI

1. **Install Railway CLI**
   ```bash
   npm install -g @railway/cli
   ```

2. **Login and Deploy**
   ```bash
   railway login
   railway init
   railway up
   ```

## Frontend Deployment (Netlify)

### Using Netlify Dashboard

1. **Connect GitHub Repository**
   - Go to [Netlify Dashboard](https://app.netlify.com/)
   - Click "New site from Git"
   - Connect your GitHub account and select the QuantVestor repository

2. **Configure Build Settings**
   - **Base directory**: `frontend`
   - **Build command**: `npm run build`
   - **Publish directory**: `frontend/dist`

3. **Environment Variables**
   - Go to Site settings > Environment variables
   - Add: `VITE_API_BASE` = `https://your-railway-backend-url.up.railway.app`
   - Replace with your actual Railway backend URL

4. **Deploy**
   - Click "Deploy site"
   - Netlify will build and deploy your frontend
   - You'll get a public URL (e.g., `https://quantvestor.netlify.app`)

## Post-Deployment Configuration

### Update CORS Settings

After deployment, update the backend CORS settings in `app/main.py`:

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173", 
        "http://127.0.0.1:5173", 
        "https://your-netlify-domain.netlify.app",  # Add your Netlify domain
        "*"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

### Test the Deployment

1. Visit your Netlify frontend URL
2. Test the application with a stock ticker (e.g., AAPL)
3. Verify that valuations and peer comparisons work correctly
4. Check that sentiment analysis is functioning

## Custom Domain (Optional)

### For Frontend (Netlify)
1. Go to Site settings > Domain management
2. Add your custom domain
3. Configure DNS settings as instructed

### For Backend (Railway)
1. Go to your Railway project settings
2. Add a custom domain in the Networking section
3. Update the frontend environment variable accordingly

## Monitoring and Maintenance

### Railway Backend
- Monitor logs in the Railway dashboard
- Set up alerts for downtime
- Monitor resource usage

### Netlify Frontend
- Check build logs for any issues
- Monitor site analytics
- Set up form handling if needed

## Troubleshooting

### Common Issues

1. **CORS Errors**
   - Ensure the frontend domain is added to CORS origins
   - Check that the API base URL is correct

2. **Build Failures**
   - Check Node.js version compatibility
   - Verify all dependencies are listed in package.json

3. **API Connection Issues**
   - Verify the VITE_API_BASE environment variable
   - Check Railway backend logs for errors

4. **Yahoo Finance API Limits**
   - The app uses yfinance which may have rate limits
   - Consider implementing caching for production use

## Security Considerations

1. **Environment Variables**
   - Never commit API keys or secrets to the repository
   - Use Railway/Netlify environment variable settings

2. **CORS Configuration**
   - Remove "*" from allowed origins in production
   - Only allow specific domains

3. **Rate Limiting**
   - Consider implementing rate limiting for the API endpoints
   - Monitor for abuse or excessive requests

## Performance Optimization

1. **Frontend**
   - Enable Netlify's asset optimization
   - Consider implementing lazy loading for charts

2. **Backend**
   - Implement caching for frequently requested stocks
   - Consider using a database for storing historical data

3. **CDN**
   - Netlify provides CDN by default
   - Consider using Railway's edge locations

## Backup and Recovery

1. **Code Repository**
   - Ensure all code is committed to GitHub
   - Use proper branching strategy

2. **Configuration**
   - Document all environment variables
   - Keep deployment configurations in version control

## Support and Updates

1. **Monitoring**
   - Set up uptime monitoring
   - Monitor error rates and performance

2. **Updates**
   - Test updates in staging environment first
   - Use Railway's preview deployments for testing

3. **Rollback**
   - Railway and Netlify support easy rollbacks
   - Keep track of working deployment versions

