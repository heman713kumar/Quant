﻿from __future__ import annotations
from typing import Dict

def _as_val(value: float, explanation: str) -> Dict:
    return {"value": round(float(value), 2), "explanation": explanation}

def calculate_valuations(basics: Dict) -> Dict:
    """
    Return a dict with keys: DCF, PE, Graham.
    Each is: { value: number, explanation: string }
    This is intentionally simple/illustrative.
    """
    eps = basics.get("eps_ttm")
    g = basics.get("growth", 0.05) or 0.05
    bv = basics.get("book_value")
    price = basics.get("price")

    out = {}

    # 1) PE-based intrinsic (fair PE ~ 15 as a sanity anchor)
    if eps is not None and eps > 0:
        pe_fair = 15
        pe_val = eps * pe_fair
        out["PE"] = _as_val(
            pe_val,
            f"PE method: EPS (ttm) {eps:.2f} × fair P/E {pe_fair}."
        )
    else:
        out["PE"] = _as_val(0, "PE method skipped: EPS unavailable.")

    # 2) Very simple DCF-ish using EPS as proxy for FCFE, 5y horizon, 10% discount
    if eps is not None and eps > 0:
        years = 5
        r = 0.10  # discount rate
        fcfe = eps
        pv = 0.0
        for t in range(1, years + 1):
            fcfe *= (1 + g)
            pv += fcfe / ((1 + r) ** t)
        # add a conservative terminal value (10× last-year FCFE discounted)
        terminal = (10 * fcfe) / ((1 + r) ** years)
        dcf_val = pv + terminal
        out["DCF"] = _as_val(
            dcf_val,
            f"DCF proxy: start EPS≈FCFE {basics.get('eps_ttm')}, growth {g*100:.1f}%, "
            f"discount {r*100:.0f}%, 5y + conservative terminal."
        )
    else:
        out["DCF"] = _as_val(0, "DCF skipped: EPS unavailable.")

    # 3) Graham-style (classic 22.5× EPS × BV)^(1/2) if both present
    if eps is not None and eps > 0 and bv is not None and bv > 0:
        graham_val = (22.5 * eps * bv) ** 0.5
        out["Graham"] = _as_val(
            graham_val,
            f"Graham formula √(22.5 × EPS {eps:.2f} × BVPS {bv:.2f})."
        )
    else:
        out["Graham"] = _as_val(0, "Graham skipped: EPS and/or Book Value unavailable.")

    # annotate what price we used for context (not a valuation)
    if price is not None:
        out["_context"] = {"market_price": round(float(price), 2)}

    return out
