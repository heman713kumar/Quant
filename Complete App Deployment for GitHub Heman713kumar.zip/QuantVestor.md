# QuantVestor

A simple stock valuation tool that provides three different valuation methods (DCF, PE, and Graham) for stocks, along with peer comparison and basic sentiment analysis.

## Features

- **Stock Valuation**: Calculate intrinsic value using DCF, PE, and Graham methods
- **Peer Comparison**: Compare valuations across multiple stocks
- **Market Sentiment**: Basic sentiment analysis using TextBlob
- **Yahoo Finance Integration**: Fetch real-time stock data
- **Responsive UI**: Clean, mobile-friendly interface built with React and Tailwind CSS

## Tech Stack

### Backend
- **FastAPI**: Modern Python web framework
- **yfinance**: Yahoo Finance data fetching
- **TextBlob**: Sentiment analysis
- **Uvicorn**: ASGI server

### Frontend
- **React**: UI framework
- **TypeScript**: Type safety
- **Vite**: Build tool
- **Tailwind CSS**: Styling
- **Recharts**: Data visualization

## Quick Start

### Prerequisites
- Python 3.11+
- Node.js 18+

### Backend Setup

1. Navigate to the project root:
```bash
cd quantvestor-app
```

2. Install Python dependencies:
```bash
pip install -r requirements.txt
```

3. Start the backend server:
```bash
uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

The API will be available at `http://127.0.0.1:8000`

### Frontend Setup

1. Navigate to the frontend directory:
```bash
cd frontend
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

The frontend will be available at `http://localhost:5173`

## Usage

1. Enter a stock ticker (e.g., AAPL) or Yahoo Finance URL
2. Optionally add peer tickers separated by commas (e.g., MSFT, GOOGL)
3. Click "Analyze" to get valuations and comparisons
4. View detailed explanations by clicking on each valuation method

## API Endpoints

### GET /
Health check endpoint

### POST /bulk-valuation
Calculate valuations for multiple stocks
```json
{
  "urls": ["AAPL", "MSFT", "GOOGL"]
}
```

### POST /sentiment
Get sentiment analysis for a stock
```json
{
  "query": "AAPL"
}
```

## Deployment

### Backend (Railway)
1. Connect your GitHub repository to Railway
2. Set the start command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
3. Deploy

### Frontend (Netlify)
1. Connect your GitHub repository to Netlify
2. Set build directory to `frontend/`
3. Set build command to `npm run build`
4. Set publish directory to `frontend/dist`
5. Add environment variable `VITE_API_BASE` with your Railway backend URL
6. Deploy

## Environment Variables

### Frontend
- `VITE_API_BASE`: Backend API URL (defaults to `http://127.0.0.1:8000`)

## License

MIT License

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## Disclaimer

This tool is for educational purposes only. The valuations provided are simplified models and should not be used as the sole basis for investment decisions. Always consult with a financial advisor before making investment decisions.

