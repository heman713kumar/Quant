﻿from __future__ import annotations
from typing import List, Dict

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from app.utils.yahoo_scraper import parse_ticker, fetch_basics
from app.utils.valuation_model import calculate_valuations

# (basic) sentiment using TextBlob; if not installed, return neutral
try:
    from textblob import TextBlob
except Exception:  # pragma: no cover
    TextBlob = None  # type: ignore

app = FastAPI(title="QuantVestor API", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class BulkBody(BaseModel):
    urls: List[str]

class SentBody(BaseModel):
    query: str

@app.get("/")
def root():
    return {"ok": True, "msg": "QuantVestor API running"}

@app.post("/bulk-valuation")
def bulk_valuation(body: BulkBody):
    data: Dict[str, Dict] = {}

    for item in body.urls:
        ticker = parse_ticker(item)
        if not ticker:
            continue
        basics = fetch_basics(ticker)
        if not basics:
            continue
        vals = calculate_valuations(basics)
        data[ticker] = vals

    return {"success": True, "data": data}

@app.post("/sentiment")
def sentiment(body: SentBody):
    # extremely simple: polarity of the ticker string itself as a stub
    # (you can replace with real news scraping later)
    if TextBlob is None:
        return {
            "success": True,
            "data": {
                "score": 0.0,
                "headlines": [],
                "explanation": "TextBlob not installed; returning neutral stub.",
            },
        }
    blob = TextBlob(body.query or "")
    score = float(blob.sentiment.polarity)
    return {
        "success": True,
        "data": {
            "score": score,
            "headlines": [],
            "explanation": "TextBlob polarity of provided query.",
        },
    }
