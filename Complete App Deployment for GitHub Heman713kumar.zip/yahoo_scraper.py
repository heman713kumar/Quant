from __future__ import annotations
import re
from typing import Dict, Optional

import yfinance as yf

_TICKER_RE = re.compile(r"/quote/([A-Za-z\-\.=]+)")

def parse_ticker(input_or_url: str) -> str:
    """
    Accept either a Yahoo URL or a bare ticker and return an UPPER-CASED ticker.
    """
    s = (input_or_url or "").strip()
    if not s:
        return ""
    if s.lower().startswith("http"):
        m = _TICKER_RE.search(s)
        if m:
            return m.group(1).upper()
        frag = s.rstrip("/").split("/")[-1].split("?")[0]
        return frag.upper()
    return s.split("?")[0].upper()

def fetch_basics(ticker: str) -> Optional[Dict]:
    """
    Fetch a few essentials with yfinance. Returns a dict even if some fields
    are missing, so the UI can still display 0-valuations with explanations.
    """
    t = (ticker or "").strip().upper()
    if not t:
        return None

    yf_t = yf.Ticker(t)
    basics: Dict = {"ticker": t}

    # Price: try fast_info -> history fallback
    try:
        price = None
        fi = getattr(yf_t, "fast_info", None) or {}
        if isinstance(fi, dict):
            price = fi.get("last_price")
        if price is None:
            hist = yf_t.history(period="1d")
            if not hist.empty:
                price = float(hist["Close"].iloc[-1])
        basics["price"] = float(price) if price is not None else None
    except Exception:
        basics["price"] = None

    # EPS (TTM)
    eps_ttm = None
    info = {}
    try:
        info = yf_t.info or {}
        eps_ttm = info.get("trailingEps")
    except Exception:
        pass
    basics["eps_ttm"] = float(eps_ttm) if isinstance(eps_ttm, (int, float)) else None

    # Growth estimate (very rough)
    growth = None
    try:
        growth = info.get("earningsGrowth") or info.get("revenueGrowth") or info.get("earningsQuarterlyGrowth")
    except Exception:
        pass
    if not isinstance(growth, (int, float)):
        growth = 0.05  # conservative default 5%
    basics["growth"] = float(growth)

    # Book value/share (for Graham)
    bvps = None
    try:
        bvps = info.get("bookValue")
    except Exception:
        pass
    basics["book_value"] = float(bvps) if isinstance(bvps, (int, float)) else None

    return basics

def scrape_yahoo_data(url_or_ticker: str):
    """Legacy function for backward compatibility"""
    t = url_or_ticker.strip()
    if t.startswith("http"):
        t = t.strip("/").split("/")[-1].split("?")[0]

    ticker = yf.Ticker(t)
    info = ticker.info or {}

    return {
        "ticker": t,
        "current_price": info.get("currentPrice"),
        "eps_ttm": info.get("trailingEps"),
        "growth_estimate": info.get("earningsQuarterlyGrowth"),
        "book_value": info.get("bookValue"),
        "pe_ratio": info.get("trailingPE"),
        "roe": info.get("returnOnEquity"),
    }

